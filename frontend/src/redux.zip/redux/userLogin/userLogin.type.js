export const USER_LOGIN = "userLogin/loginSuccess";
export const USER_LOGOUT = "userLogout/logoutSuccess";
export const USER_LOGIN_ERROR = "userLogin/Error";