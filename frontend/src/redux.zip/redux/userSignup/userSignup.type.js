export const USER_SIGNUP = "userSignup/Success";
export const USER_SIGNUP_ERROR = "userSignup/Error";